package com.example.gen_ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenAiApplication.class, args);
	}

}
